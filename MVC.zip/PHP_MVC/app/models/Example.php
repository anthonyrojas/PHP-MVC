<?php
//Sample model class for this framework
//delete or edit as it suits your need
class Example{
  private $db;
  public function __construct(){
    $this->db = new Database;
  }
}
