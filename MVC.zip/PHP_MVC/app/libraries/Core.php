<?php
/**
*App Core class
*Creates URL and loads core Controller
*URL Format - controller/method/params
*/
class Core{
  //by default this controller will be called
  //change it to make it an error handling page. i.e., 404
  protected $currentController = 'Pages';
  protected $currentMethod = 'index';
  protected $params = [];
  public function __construct(){
    $url = $this->getUrl();
    //look in controllers (as if we were in index.php) for first value
    if(file_exists('../app/controllers/' . ucwords($url[0]) . '.php')){
      //if exists, set as controller
      $this->currentController = ucwords($url[0]);
      //unset [0] Index
      unset($url[0]);
    }

    //require the controller
    require_once '../app/controllers/' . $this->currentController . '.php';
    //instantiate the controller
    $this->currentController = new $this->currentController;
    //check for second part of the url
    if(isset($url[1])){
      //check to see if a method exists in a controller
      if(method_exists($this->currentController, $url[1])){
        $this->currentMethod = $url[1];
        //unset 1 index
        unset($url[1]);
      }
    }

    //get params
    $this->params = $url ? array_values($url) : [];
    //call a callback with array of params
    call_user_func_array([$this->currentController, $this->currentMethod], $this->params);

  }
  public function getUrl(){
    if(isset($_GET['url'])){
      $url = rtrim($_GET['url'], '/');
      $url = filter_var($url, FILTER_SANTITIZE_URL);
      $url = explode('/', $url);
      return $url;
    }
  }
}
?>
