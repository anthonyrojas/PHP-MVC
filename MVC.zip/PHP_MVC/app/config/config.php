<?php
// DB params
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '123456');
define('DB_NAME', 'default');
//App Root
define('APPROOT', dirname(dirname(__FILE__)));
//URL root
define('URLROOT', 'http://localhost/PHP_MVC');
//site name
define('SITENAME', 'PHP_MVC');
?>
