<?php
	require_once '../app/bootstrap.php';
	//init core library
	$init = new Core;
?>
